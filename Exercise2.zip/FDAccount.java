package com.exerciseProject1.modal;

public class FDAccount extends Account {

	private int tenure;
	private boolean autoRenewal;
	
	
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	public boolean isAutoRenewal() {
		return autoRenewal;
	}
	public void setAutoRenewal(boolean autoRenewal) {
		this.autoRenewal = autoRenewal;
	}
	
	
	public void updateFDAccounttype(String FDAccounttype) {
		
		this.autoRenewal=true;
		
	System.out.println("FDAccounttype is "+this.autoRenewal);
	}
}
