package com.exercise1.service;

import com.exerciseProject1.modal.Account;
import com.exerciseProject1.modal.CurrentAccount;
import com.exerciseProject1.modal.FDAccount;
import com.exerciseProject1.modal.LoanAccount;

public class Accountdetail {

	public static void main(String args[]) {
		
		Account Acc=new Account();
		
		Acc.setAccountnumber(23455667);
		Acc.setName("Sophia");
		Acc.setbalance(50000);
		
		Acc.withdrawMoney(5);
		

	System.out.println("Name is "+Acc.getName());
	System.out.println("Accontnumber is "+Acc.getAccountnumber());
	
	
      FDAccount FD=new FDAccount();
      
      FD.setAccountnumber(23455667);
      FD.setName("Sophia");
      FD.setAmount(2000);
      FD.setTenure(5);
      FD.updateFDAccounttype("yes");
      FD.loanOutBalance(FD.getAmount());
      
      CurrentAccount CA= new CurrentAccount();
      
      CA.setAccountnumber(23097767);
      CA.setName("Betsy");
      CA.setAmount(3000);
      CA.setOverDraftLimit(CA.getOverDraftLimit()*3);
      System.out.println("OverDraftLimit"+CA.getOverDraftLimit());
      CA.loanOutBalance(FD.getAmount());
      
      LoanAccount LA=new LoanAccount();
      
      LA.setAccountnumber(73557767);
      LA.setName("Greta");
      LA.setAmount(1000);
      LA.loanOutBalance(LA.getAmount());
      LA.setTenure(3);
      LA.EmiCalulate(CA.getAmount());    
      
}
}
