package com.exerciseProject1.modal;

public class LoanAccount extends Account{

	private float tenure ;
	private int emi;
	private int loanOutStanding;
	
	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public int getEmi() {
		return emi;
	}

	public void setEmi(int emi) {
		this.emi = emi;
	}

	public int getLoanOutStanding() {
		return loanOutStanding;
	}
	
	public void setLoanOutStanding(int loanOutStanding) {
		this.loanOutStanding = loanOutStanding;
	}
	

	public void EmiCalulate( float balance) {
		 this.emi=(int) (balance/tenure);
		 
		 System.out.println("emi"+this.emi);
	}


}
