package com.exerciseProject1.Util;

public class InterestCal
{
		float p;
		int n;
		float r;
		
	public void SBAccount(float amount,int period) {

		r=.6f;
		float Interest=amount*period*r;
		System.out.println("SBAccount Interst is "+ Interest);
		
	}

	public void FDAccount(float amount,int period) {

		r=.9f;
		float Interest=amount*period*r;
		System.out.println("FDAccount Interst is "+ Interest);
		
	}
}

