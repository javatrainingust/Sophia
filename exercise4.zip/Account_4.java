package com.exerciseProject1.modal;

import com.exerciseProject1.Util.InterestCal;

public class Account{

	private int accountnumber;
	private String name;
	private float balance;
	private float amount;
	
	InterestCal ic=new InterestCal();

	public int getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public float getbalance() {
		return balance;
	}
	
	public void setbalance(float balance) {
		this.balance = balance;
	}
	
	   public float getAmount() {
		return amount;
	  }

	  public void setAmount(float amount) {
		this.amount = amount;
	  }

	
   public void withdrawMoney(float amountToWithdraw){
		
		this.balance=this.balance-amountToWithdraw;
		
	System.out.println("Balance is "+balance);	
	}

  public void loanOutBalance(float amount) {
	
	  this.balance=amount;
	  
	  System.out.println("Balance"+this.balance);
	   
 }

  public void CalculateInterest(float Amt)
	{
		System.out.println(""+Amt);
		ic.SBAccount(Amt,2);
		
	}

public void upautoRenewal(int tenure) {
	// TODO Auto-generated method stub
	
}  
  }
  
