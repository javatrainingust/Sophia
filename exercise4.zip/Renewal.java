package com.exerciseProject1.modal;

public interface Renewal {
	
	public void upautoRenewal(int tenure);


}