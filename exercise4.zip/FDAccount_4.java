package com.exerciseProject1.modal;

import com.exerciseProject1.Util.InterestCal;

public class FDAccount extends Account implements Renewal{

	private int tenure;
	private boolean autoRenewal;
	
	InterestCal ic=new InterestCal();
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	public boolean isAutoRenewal() {
		return autoRenewal;
	}
	public void setAutoRenewal(boolean autoRenewal) {
		this.autoRenewal = autoRenewal;
	}
	
	
	public void updateFDAccounttype(String FDAccounttype) {
		
		this.autoRenewal=true;
		
	System.out.println("FDAccounttype is "+this.autoRenewal);
	}
	
	public void CalculateInterest(float Amt)
	{
		System.out.println(""+Amt);
		ic.FDAccount(Amt,1);
		
	}
	@Override

	public void upautoRenewal(int tenure) {
		
		this.tenure=4;
		
	System.out.println("upautoRenewal"+this.tenure);
	}
}









