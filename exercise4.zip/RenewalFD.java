package com.exercise1.service;

import com.exerciseProject1.modal.FDAccount;
import com.exerciseProject1.modal.Renewal;

public class RenewalFD {
	
	public static void main(String args[]) {
		
		Renewal r = new FDAccount();
		
		r.upautoRenewal(4);
		
	}

}
