package com.exerciseProject1.modal;

import com.exerciseProject1.Util.InterestCal;

public class SBAccount extends Account {
	
	InterestCal ic=new InterestCal();

	public void CalculateInterest(float Amt)
	{
		System.out.println(""+Amt);
		ic.SBAccount(Amt,5);
		
	}
}
